
alert('Javascript is connected!');


function testFunction() {
    alert("javascript file is linked");
  }
